<?
$arModuleVersion = array(
	"VERSION" => "0.2.0",
	"VERSION_DATE" => "2021-01-28 09:00:00"
);
?>